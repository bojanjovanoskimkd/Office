#include <windows.h>
int APIENTRY wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    MessageBoxW(nullptr, L"Flutter Windows runner placeholder. Run `flutter create .` in a Flutter SDK environment to generate the managed Windows runner.", L"Регистар на предмети", MB_OK);
    return 0;
}
