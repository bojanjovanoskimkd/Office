# Windows target
The application source supports Windows through sqflite_common_ffi. The generated Flutter Windows runner should be finalized with `flutter create .` from the project root in a Flutter SDK environment.
