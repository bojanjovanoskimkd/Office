# Android Release Checklist — v0.17

- [x] Version bumped to 0.16.0+16
- [x] Existing v0.15 functionality retained
- [x] Legal categories retained
- [x] Dashboard by category retained
- [x] Google Drive sync retained
- [ ] Run `flutter pub get`
- [ ] Run `flutter analyze`
- [ ] Run `flutter build apk --release`
- [ ] Install APK on physical Android device
- [ ] Test creating client
- [ ] Test creating case
- [ ] Test documents/scanning
- [ ] Test timeline
- [ ] Test completing case
- [ ] Test search/filter
- [ ] Test Google Drive sync

## Current environment
Flutter/Android build tools are not installed in this environment. Therefore the APK build remains the final external build step.
