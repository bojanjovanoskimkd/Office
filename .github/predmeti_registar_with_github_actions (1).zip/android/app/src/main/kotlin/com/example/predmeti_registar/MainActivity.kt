package com.example.predmeti_registar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
