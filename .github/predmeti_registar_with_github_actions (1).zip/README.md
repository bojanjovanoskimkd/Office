# Предмети Регистар — Flutter Project v0.18

Професионален регистар на странки и предмети за Android и Windows.

## Проектен корен

Оваа папка е **Flutter project root**. Во неа се наоѓа `pubspec.yaml` и директориумите `lib/`, `android/` и `windows/`. Не постои посебен задолжителен `.project` фајл во Flutter; IDE-јата го отвора целиот директориум.

## Важно

Овој пакет е подготвен без инсталиран Flutter SDK во средината каде што е креиран. Затоа не е извршена компајлација и не треба да се смета за build-verified APK/Windows executable.

Во средина со инсталиран Flutter SDK, од root директориумот изврши:

```bash
flutter create .
flutter pub get
flutter analyze
flutter build apk --release
```

`flutter create .` служи за регенерирање/освежување на платформските и генерираните Flutter датотеки според точната верзија на Flutter SDK што ја користиш.

## Главни делови

- `lib/main.dart` — главната апликација
- `lib/sync_service.dart` — синхронизација
- `android/` — Android проект
- `windows/` — Windows проект
- `pubspec.yaml` — Flutter зависности и верзија
- `analysis_options.yaml` — Dart/Flutter lint правила
- `predmeti_registar.project` — информативен project marker

## Верзија

`0.18.0+18`

## Android applicationId

`com.example.predmeti_registar`
