# Predmeti Registar — Project

This is a Flutter project. The project root is the folder containing `pubspec.yaml`.

Open the **root folder** in Android Studio or VS Code — do not open the ZIP itself.

Before the first build, install Flutter SDK and Android SDK, then run:

```bash
flutter doctor
flutter pub get
flutter analyze
flutter build apk --release
```

The Android Studio project files are under `.idea/` and the Android Gradle project is under `android/`.
