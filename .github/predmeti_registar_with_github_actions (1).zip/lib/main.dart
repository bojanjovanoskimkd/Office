import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'sync_service.dart';

const List<String> caseAreas = <String>[
  'Граѓанска Постапка',
  'Кривична Постапка',
  'Управна Постапка',
  'Управен спор',
  'Вонпроцесна Постапка',
  'Оставинска Постапка',
  'Постапка пред МВР',
  'Договори',
  'Постапка пред Стразбург',
  'Советување',
];

String newUid() => '${DateTime.now().microsecondsSinceEpoch}-${DateTime.now().millisecondsSinceEpoch}-${DateTime.now().microsecondsSinceEpoch % 1000003}';
String nowUtc() => DateTime.now().toUtc().toIso8601String();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }
  await AppDatabase.instance.init();
  runApp(const RegistryApp());
}

class RegistryApp extends StatelessWidget {
  const RegistryApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Регистар на предмети',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF17365D), brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF4F6F9),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF4F6F9), foregroundColor: Color(0xFF172B4D), elevation: 0, centerTitle: false),
      cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(16)))),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: Color(0xFFD9E0EA))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: Color(0xFFD9E0EA))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: Color(0xFF17365D), width: 1.5)),
      ),
    ),
    home: const HomePage(),
  );
}

class AppDatabase {
  AppDatabase._();
  static final instance = AppDatabase._();
  Database? _db;
  Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(dir.path, 'registar.db');
    _db = await openDatabase(dbPath, version: 6, onCreate: (db, v) async {
      await db.execute('CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT UNIQUE, name TEXT NOT NULL, phone TEXT, note TEXT, updatedAt TEXT NOT NULL)');
      await db.execute('CREATE TABLE cases(id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT UNIQUE, clientId INTEGER NOT NULL, caseNumber TEXT NOT NULL, area TEXT NOT NULL, court TEXT, opponent TEXT, status TEXT NOT NULL, createdAt TEXT NOT NULL, updatedAt TEXT NOT NULL, FOREIGN KEY(clientId) REFERENCES clients(id))');
      await db.execute('CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT UNIQUE, caseId INTEGER NOT NULL, eventDate TEXT NOT NULL, title TEXT NOT NULL, note TEXT, updatedAt TEXT NOT NULL, FOREIGN KEY(caseId) REFERENCES cases(id))');
      await db.execute('CREATE TABLE documents(id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT UNIQUE, caseId INTEGER NOT NULL, name TEXT NOT NULL, path TEXT NOT NULL, createdAt TEXT NOT NULL, updatedAt TEXT NOT NULL, FOREIGN KEY(caseId) REFERENCES cases(id))');
      await db.execute('CREATE TABLE sync_meta(key TEXT PRIMARY KEY, value TEXT)');
    }, onUpgrade: (db, oldVersion, newVersion) async {
      if (oldVersion < 2) {
        await db.execute('CREATE TABLE documents(id INTEGER PRIMARY KEY AUTOINCREMENT, caseId INTEGER NOT NULL, name TEXT NOT NULL, path TEXT NOT NULL, createdAt TEXT NOT NULL, FOREIGN KEY(caseId) REFERENCES cases(id))');
      }
      if (oldVersion < 3) {
        // Events table already exists in v2 schema; this migration is reserved for v3.
      }
      if (oldVersion < 4) {
        await db.execute("ALTER TABLE clients ADD COLUMN uid TEXT");
        await db.execute("ALTER TABLE cases ADD COLUMN uid TEXT");
        await db.execute("ALTER TABLE events ADD COLUMN uid TEXT");
        await db.execute("ALTER TABLE documents ADD COLUMN uid TEXT");
      }
      if (oldVersion < 5) {
        await db.execute("ALTER TABLE clients ADD COLUMN updatedAt TEXT");
        await db.execute("ALTER TABLE cases ADD COLUMN updatedAt TEXT");
        await db.execute("ALTER TABLE events ADD COLUMN updatedAt TEXT");
        await db.execute("ALTER TABLE documents ADD COLUMN updatedAt TEXT");
        final stamp = nowUtc();
        await db.execute("UPDATE clients SET updatedAt=? WHERE updatedAt IS NULL", [stamp]);
        await db.execute("UPDATE cases SET updatedAt=createdAt WHERE updatedAt IS NULL");
        await db.execute("UPDATE events SET updatedAt=eventDate WHERE updatedAt IS NULL");
        await db.execute("UPDATE documents SET updatedAt=createdAt WHERE updatedAt IS NULL");
      }
      if (oldVersion < 6) {
        await db.execute('CREATE TABLE IF NOT EXISTS sync_meta(key TEXT PRIMARY KEY, value TEXT)');
      }
    });
  }
  Database get db => _db!;
}

Future<Directory> registryRoot() async {
  final docs = await getApplicationDocumentsDirectory();
  final root = Directory(p.join(docs.path, 'REGISTAR'));
  await root.create(recursive: true);
  await Directory(p.join(root.path, 'АКТИВНИ')).create(recursive: true);
  await Directory(p.join(root.path, 'ЗАВРШЕНИ')).create(recursive: true);
  return root;
}

String safeName(String value) => value.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');

Future<Directory> createCaseFolders({required String client, required String caseNumber, bool completed = false}) async {
  final root = await registryRoot();
  final status = completed ? 'ЗАВРШЕНИ' : 'АКТИВНИ';
  final base = Directory(p.join(root.path, status, safeName(client), safeName('Предмет_${caseNumber}')));
  for (final name in ['Документи', 'Поднесоци', 'Одлуки', 'Тек_на_предметот']) {
    await Directory(p.join(base.path, name)).create(recursive: true);
  }
  return base;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  int clients = 0, active = 0, done = 0;
  bool autoSyncBusy = false;
  List<Map<String, dynamic>> recentCases = [];
  List<Map<String, dynamic>> recentEvents = [];
  Map<String,int> areaCounts = {};

  @override void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); load(); _autoSync(); }
  @override void dispose() { WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  @override void didChangeAppLifecycleState(AppLifecycleState state) { if (state == AppLifecycleState.resumed) _autoSync(); }

  Future<void> _autoSync() async {
    if (autoSyncBusy) return; autoSyncBusy = true;
    try { await SyncService.instance.sync(AppDatabase.instance.db, automatic: true); } catch (_) {}
    autoSyncBusy = false; if (mounted) load();
  }

  Future<void> load() async {
    final db = AppDatabase.instance.db;
    final c = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM clients')) ?? 0;
    final a = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM cases WHERE status='Активен'")) ?? 0;
    final d = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM cases WHERE status='Завршен'")) ?? 0;
    final rc = await db.rawQuery("SELECT cases.*, clients.name clientName FROM cases JOIN clients ON clients.id=cases.clientId ORDER BY datetime(cases.updatedAt) DESC, cases.id DESC LIMIT 5");
    final re = await db.rawQuery("SELECT events.*, cases.caseNumber, clients.name clientName FROM events JOIN cases ON cases.id=events.caseId JOIN clients ON clients.id=cases.clientId ORDER BY datetime(events.eventDate) DESC, events.id DESC LIMIT 5");
    final areaRows = await db.rawQuery('SELECT area, COUNT(*) total FROM cases GROUP BY area');
    final ac = <String,int>{for (final area in caseAreas) area: 0};
    for (final row in areaRows) { final area='${row['area'] ?? ''}'; if (ac.containsKey(area)) ac[area]=(row['total'] as int?) ?? 0; }
    if (mounted) setState(() { clients=c; active=a; done=d; recentCases=rc; recentEvents=re; areaCounts=ac; });
  }

  Future<void> _openCases() async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const CasesPage())); load(); }
  Future<void> _openClients() async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const ClientsPage())); load(); }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Row(children: [
        Container(width: 38, height: 38, decoration: BoxDecoration(color: const Color(0xFF17365D), borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.account_balance, color: Colors.white, size: 21)),
        const SizedBox(width: 12),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ПРЕДМЕТИ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: 1.2)), Text('Регистар', style: TextStyle(fontSize: 12, color: Color(0xFF68778D)))]),
      ]),
      actions: [IconButton(tooltip: 'Синхронизација', onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const SyncPage())); load(); }, icon: const Icon(Icons.cloud_sync_outlined))],
    ),
    body: RefreshIndicator(onRefresh: load, child: LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 850;
      return ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 32), children: [
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Контролна табла', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Color(0xFF172B4D))), SizedBox(height: 4), Text('Ваш централен преглед на предмети, странки и активности', style: TextStyle(color: Color(0xFF68778D)))])),
          if (wide) OutlinedButton.icon(onPressed: _openCases, icon: const Icon(Icons.search), label: const Text('Пребарај предмети')),
        ]),
        const SizedBox(height: 20),
        wide ? Row(children: [Expanded(child: StatCard(label:'Странки', value:clients.toString(), icon:Icons.people_alt_outlined)), const SizedBox(width:12), Expanded(child: StatCard(label:'Активни предмети', value:active.toString(), icon:Icons.folder_open)), const SizedBox(width:12), Expanded(child: StatCard(label:'Завршени предмети', value:done.toString(), icon:Icons.task_alt))]) : Row(children: [StatCard(label:'Странки', value:clients.toString(), icon:Icons.people_alt_outlined), const SizedBox(width:10), StatCard(label:'Активни', value:active.toString(), icon:Icons.folder_open), const SizedBox(width:10), StatCard(label:'Завршени', value:done.toString(), icon:Icons.task_alt)]),
        const SizedBox(height: 22),
        const Text('Брзи акции', style: TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:Color(0xFF172B4D))), const SizedBox(height:10),
        wide ? Row(children: [Expanded(child: _actionCard(context, Icons.people_alt_outlined, 'Странки', 'Профили, предмети и пребарување', _openClients)), const SizedBox(width:10), Expanded(child: _actionCard(context, Icons.folder_copy_outlined, 'Предмети', 'Пребарување, филтри и детали', _openCases)), const SizedBox(width:10), Expanded(child: _actionCard(context, Icons.sync_rounded, 'Синхронизација', 'Google Drive • двонасочна синхронизација', () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const SyncPage())); load(); }))]) : Column(children: [_actionCard(context, Icons.people_alt_outlined, 'Странки', 'Профили, предмети и пребарување', _openClients), const SizedBox(height:10), _actionCard(context, Icons.folder_copy_outlined, 'Предмети', 'Пребарување, филтри и детали', _openCases), const SizedBox(height:10), _actionCard(context, Icons.sync_rounded, 'Синхронизација', 'Google Drive • двонасочна синхронизација', () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const SyncPage())); load(); })]),
        const SizedBox(height:24),
        Row(children:[const Expanded(child:Text('Предмети по област',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:Color(0xFF172B4D)))),TextButton.icon(onPressed:_openCases,icon:const Icon(Icons.folder_copy_outlined,size:18),label:const Text('Сите предмети'))]),
        const SizedBox(height:10),
        LayoutBuilder(builder:(context, box){
          final cols=box.maxWidth>=1050?4:box.maxWidth>=700?3:box.maxWidth>=430?2:1;
          return GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:caseAreas.length,gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:cols,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:2.7),itemBuilder:(_,i)=>_areaCard(context,caseAreas[i],areaCounts[caseAreas[i]]??0));
        }),
        const SizedBox(height:24),
        wide ? Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:_recentCasesCard(context)),const SizedBox(width:14),Expanded(child:_recentEventsCard())]) : Column(children:[_recentCasesCard(context),const SizedBox(height:14),_recentEventsCard()]),
        const SizedBox(height:18),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.security_outlined,color:Color(0xFF17365D))),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Организиран регистар',style:TextStyle(fontWeight:FontWeight.w700)),SizedBox(height:3),Text('Секој предмет има сопствена структура за документи и тек на предметот.',style:TextStyle(fontSize:12,color:Color(0xFF68778D)))]))]))),
      ];
    })),
  );

  Widget _areaCard(BuildContext context, String area, int count) => Card(elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14),side:const BorderSide(color:Color(0xFFE3E8EF))),child:InkWell(borderRadius:BorderRadius.circular(14),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CasesPage(initialArea:area))).then((_)=>load()),child:Padding(padding:const EdgeInsets.symmetric(horizontal:13,vertical:10),child:Row(children:[Container(width:38,height:38,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(11)),child:const Icon(Icons.folder_outlined,color:Color(0xFF17365D),size:20)),const SizedBox(width:10),Expanded(child:Text(area,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700,color:Color(0xFF172B4D)))),const SizedBox(width:6),Text('$count',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:Color(0xFF17365D))),const SizedBox(width:3),const Icon(Icons.chevron_right,size:17,color:Color(0xFF9AA5B5))]))));

  Widget _actionCard(BuildContext context, IconData icon, String title, String subtitle, VoidCallback action) => Card(child:InkWell(borderRadius:BorderRadius.circular(16),onTap:action,child:Padding(padding:const EdgeInsets.all(15),child:Row(children:[Container(width:46,height:46,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:const Color(0xFF17365D))),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700)),const SizedBox(height:3),Text(subtitle,style:const TextStyle(fontSize:12,color:Color(0xFF68778D)))])),const Icon(Icons.chevron_right,color:Color(0xFF8A97A8))]))));

  Widget _recentCasesCard(BuildContext context) => Card(child:Padding(padding:const EdgeInsets.fromLTRB(16,16,10,10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Expanded(child:Text('Последни предмети',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:Color(0xFF172B4D)))),TextButton(onPressed:_openCases,child:const Text('Види сè'))]),if(recentCases.isEmpty) const Padding(padding:EdgeInsets.fromLTRB(0,10,0,12),child:Text('Сè уште нема внесени предмети.',style:TextStyle(color:Color(0xFF68778D)))) else ...recentCases.map((x)=>ListTile(contentPadding:EdgeInsets.zero,dense:true,leading:Container(width:38,height:38,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(10)),child:const Icon(Icons.folder_outlined,color:Color(0xFF17365D))),title:Text('${x['caseNumber']}  •  ${x['area']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('${x['clientName']}  •  ${x['status']}',maxLines:1,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right,size:18,color:Color(0xFF9AA5B5)),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CaseDetailsPage(caseData:x))).then((_)=>load()))])));

  Widget _recentEventsCard() => Card(child:Padding(padding:const EdgeInsets.fromLTRB(16,16,16,12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Последни активности',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:Color(0xFF172B4D))),const SizedBox(height:8),if(recentEvents.isEmpty) const Padding(padding:EdgeInsets.only(bottom:8),child:Text('Активностите на предметите ќе се појават тука.',style:TextStyle(color:Color(0xFF68778D)))) else ...recentEvents.map((x){final dt=DateTime.tryParse('${x['eventDate']}');final date=dt==null?'':DateFormat('dd.MM.yyyy HH:mm').format(dt.toLocal());return ListTile(contentPadding:EdgeInsets.zero,dense:true,leading:Container(width:34,height:34,decoration:BoxDecoration(color:const Color(0xFFF1F4F8),borderRadius:BorderRadius.circular(10)),child:const Icon(Icons.timeline,size:18,color:Color(0xFF17365D))),title:Text('${x['title']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text('${x['clientName']} • ${x['caseNumber']}\n$date',maxLines:2,overflow:TextOverflow.ellipsis));})])));
}

class StatCard extends StatelessWidget { final String label,value; final IconData icon; const StatCard({super.key,required this.label,required this.value,required this.icon}); @override Widget build(BuildContext c)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.symmetric(horizontal:14,vertical:15),child:Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(12)),child:Icon(icon,size:21,color:const Color(0xFF17365D))),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(value,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800,color:Color(0xFF172B4D))),Text(label,style:const TextStyle(fontSize:11,color:Color(0xFF68778D)))]))])))); }

class NewClientPage extends StatefulWidget { const NewClientPage({super.key}); @override State<NewClientPage> createState()=>_NewClientPageState(); }
class _NewClientPageState extends State<NewClientPage> {
  final name=TextEditingController(), phone=TextEditingController(), note=TextEditingController();
  @override void dispose(){name.dispose();phone.dispose();note.dispose();super.dispose();}
  Future<void> save() async {
    if(name.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Внесете име / назив на странката.')));return;}
    final id=await AppDatabase.instance.db.insert('clients', {'uid':newUid(),'name':name.text.trim(),'phone':phone.text.trim(),'note':note.text.trim(),'updatedAt':nowUtc()});
    await Directory(p.join((await registryRoot()).path,'АКТИВНИ',safeName(name.text))).create(recursive:true);
    if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Странката е креирана (#$id)')));Navigator.pop(context,true);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Нова странка')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(18)),child:const Row(children:[Icon(Icons.person_add_alt_1,size:30,color:Color(0xFF17365D)),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Основни податоци',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:Color(0xFF172B4D))),SizedBox(height:3),Text('Податоците ќе бидат достапни во профилот на странката.',style:TextStyle(fontSize:12,color:Color(0xFF68778D)))]))])),
      const SizedBox(height:18),
      TextField(controller:name,decoration:const InputDecoration(labelText:'Име / назив на странка',hintText:'Пр. Иван Иванов / ДООЕЛ Компанија',prefixIcon:Icon(Icons.person_outline),border:OutlineInputBorder())),
      const SizedBox(height:12),
      TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Телефон',prefixIcon:Icon(Icons.phone_outlined),border:OutlineInputBorder())),
      const SizedBox(height:12),
      TextField(controller:note,maxLines:4,decoration:const InputDecoration(labelText:'Белешка',hintText:'Дополнителни информации...',prefixIcon:Icon(Icons.notes_outlined),border:OutlineInputBorder(),alignLabelWithHint:true)),
      const SizedBox(height:22),
      SizedBox(width:double.infinity,height:50,child:FilledButton.icon(onPressed:save,icon:const Icon(Icons.save_outlined),label:const Text('Зачувај странка'))),
    ])
  );
}

class ClientsPage extends StatefulWidget { const ClientsPage({super.key}); @override State<ClientsPage> createState()=>_ClientsPageState(); }
class _ClientsPageState extends State<ClientsPage> {
  final search=TextEditingController();
  List<Map<String,dynamic>> clients=[];
  Map<int,Map<String,int>> counts={};
  @override void initState(){super.initState();search.addListener(()=>setState((){}));load();}
  @override void dispose(){search.dispose();super.dispose();}
  Future<void> load() async {
    final db=AppDatabase.instance.db;
    clients=await db.query('clients',orderBy:'name COLLATE NOCASE ASC');
    final rows=await db.rawQuery("SELECT clientId, SUM(CASE WHEN status='Активен' THEN 1 ELSE 0 END) active, SUM(CASE WHEN status='Завршен' THEN 1 ELSE 0 END) done, COUNT(*) total FROM cases GROUP BY clientId");
    counts={for(final x in rows)(x['clientId'] as int):{'active':(x['active'] as int?)??0,'done':(x['done'] as int?)??0,'total':(x['total'] as int?)??0}};
    if(mounted)setState((){});
  }
  Future<void> addClient()async{final ok=await Navigator.push(context,MaterialPageRoute(builder:(_)=>const NewClientPage()));if(ok==true)load();}
  List<Map<String,dynamic>> get filtered{
    final q=search.text.trim().toLowerCase();
    if(q.isEmpty)return clients;
    return clients.where((x)=>'${x['name']} ${x['phone']??''} ${x['note']??''}'.toLowerCase().contains(q)).toList();
  }
  Widget _stat(String value,String label){return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(value,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:15,color:Color(0xFF172B4D))),Text(label,style:const TextStyle(fontSize:10,color:Color(0xFF68778D)))]);}
  @override Widget build(BuildContext context){final shown=filtered;final total=clients.length;final withCases=clients.where((x)=>(counts[x['id']]?['total']??0)>0).length;return Scaffold(
    appBar:AppBar(title:const Text('Странки'),actions:[IconButton(onPressed:load,tooltip:'Освежи',icon:const Icon(Icons.refresh)),IconButton(onPressed:addClient,tooltip:'Нова странка',icon:const Icon(Icons.person_add_alt_1))]),
    floatingActionButton:FloatingActionButton.extended(onPressed:addClient,icon:const Icon(Icons.person_add_alt_1),label:const Text('Нова странка')),
    body:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(12,12,12,8),child:TextField(controller:search,decoration:InputDecoration(hintText:'Пребарај по име, телефон или белешка...',prefixIcon:const Icon(Icons.search),suffixIcon:search.text.isEmpty?null:IconButton(onPressed:()=>search.clear(),icon:const Icon(Icons.clear)),filled:true,fillColor:const Color(0xFFF4F6F9),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none)))),
      Padding(padding:const EdgeInsets.fromLTRB(12,0,12,10),child:Row(children:[_stat('$total','Вкупно странки'),const SizedBox(width:28),_stat('$withCases','Со предмети'),const Spacer(),Text('${shown.length} прикажани',style:const TextStyle(fontSize:12,color:Color(0xFF68778D),fontWeight:FontWeight.w600))])),
      Expanded(child:shown.isEmpty?Center(child:Padding(padding:const EdgeInsets.all(30),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(clients.isEmpty?Icons.people_outline:Icons.search_off_outlined,size:54,color:const Color(0xFF9AA5B5)),const SizedBox(height:12),Text(clients.isEmpty?'Нема внесени странки.':'Нема странки според пребарувањето.',style:const TextStyle(fontWeight:FontWeight.w700,color:Color(0xFF68778D))),if(clients.isEmpty) ...[const SizedBox(height:14),FilledButton.icon(onPressed:addClient,icon:const Icon(Icons.person_add_alt_1),label:const Text('Додај прва странка'))]]))):ListView.builder(padding:const EdgeInsets.fromLTRB(12,0,12,90),itemCount:shown.length,itemBuilder:(_,i){final x=shown[i];final id=x['id'] as int;final c=counts[id]??{'active':0,'done':0,'total':0};return Card(margin:const EdgeInsets.only(bottom:8),elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14),side:const BorderSide(color:Color(0xFFE3E8EF))),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:8),leading:Container(width:48,height:48,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(14)),child:const Icon(Icons.person_outline,color:Color(0xFF17365D),size:25)),title:Text('${x['name']}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF172B4D))),subtitle:Padding(padding:const EdgeInsets.only(top:6),child:Row(children:[if('${x['phone']??''}'.isNotEmpty) ...[const Icon(Icons.phone_outlined,size:14,color:Color(0xFF7A8798)),const SizedBox(width:4),Flexible(child:Text('${x['phone']}',overflow:TextOverflow.ellipsis)),const SizedBox(width:12)],Text('Активни ${c['active']}',style:const TextStyle(fontSize:12)),const SizedBox(width:10),Text('Завршени ${c['done']}',style:const TextStyle(fontSize:12,color:Color(0xFF68778D)))])),trailing:const Icon(Icons.chevron_right,color:Color(0xFF9AA5B5)),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ClientProfilePage(client:x))).then((_)=>load()));}))
    ])
  );}
}

class ClientProfilePage extends StatefulWidget { final Map<String,dynamic> client; const ClientProfilePage({super.key,required this.client}); @override State<ClientProfilePage> createState()=>_ClientProfilePageState(); }
class _ClientProfilePageState extends State<ClientProfilePage>{
  List<Map<String,dynamic>> cases=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{cases=await AppDatabase.instance.db.rawQuery('SELECT cases.*, clients.name clientName FROM cases JOIN clients ON clients.id=cases.clientId WHERE cases.clientId=? ORDER BY datetime(cases.updatedAt) DESC, cases.id DESC',[widget.client['id']]);if(mounted)setState((){});}
  Widget _info(IconData icon,String label,String value){if(value.trim().isEmpty)return const SizedBox.shrink();return Padding(padding:const EdgeInsets.only(bottom:10),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,size:19,color:const Color(0xFF17365D)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontSize:11,color:Color(0xFF68778D)),),const SizedBox(height:2),Text(value,style:const TextStyle(fontWeight:FontWeight.w600,color:Color(0xFF172B4D)))]))]));}
  Widget _status(String status){final done=status=='Завршен';return Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:done?const Color(0xFFE9F7EF):const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(18)),child:Text(status,style:TextStyle(fontSize:11,fontWeight:FontWeight.w800,color:done?const Color(0xFF247A49):const Color(0xFF17365D))));}
  @override Widget build(BuildContext context){final active=cases.where((x)=>x['status']!='Завршен').length;final done=cases.length-active;return Scaffold(appBar:AppBar(title:const Text('Профил на странка'),actions:[IconButton(onPressed:load,tooltip:'Освежи',icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.fromLTRB(14,10,14,30),children:[
    Card(elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18),side:const BorderSide(color:Color(0xFFE3E8EF))),child:Padding(padding:const EdgeInsets.all(18),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(width:58,height:58,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(17)),child:const Icon(Icons.person,size:31,color:Color(0xFF17365D))),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${widget.client['name']}',style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:Color(0xFF172B4D))),const SizedBox(height:10),_info(Icons.phone_outlined,'Телефон','${widget.client['phone']??''}'),_info(Icons.notes_outlined,'Белешка','${widget.client['note']??''}')]))]))),
    const SizedBox(height:14),
    Row(children:[Expanded(child:_metricCard('$active','Активни',Icons.folder_open)),const SizedBox(width:10),Expanded(child:_metricCard('$done','Завршени',Icons.task_alt)),const SizedBox(width:10),Expanded(child:_metricCard('${cases.length}','Вкупно',Icons.folder_copy_outlined))]),
    const SizedBox(height:22),
    Row(children:[const Expanded(child:Text('Предмети на странката',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:Color(0xFF172B4D)))),TextButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CasesPage())).then((_)=>load()),icon:const Icon(Icons.list_alt,size:18),label:const Text('Сите предмети'))]),
    const SizedBox(height:6),
    if(cases.isEmpty) Card(elevation:0,child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Icon(Icons.folder_open_outlined,size:42,color:Color(0xFF9AA5B5)),const SizedBox(height:8),const Text('Странката сè уште нема предмети.',style:TextStyle(fontWeight:FontWeight.w700,color:Color(0xFF68778D)))]))) else ...cases.map((x)=>Card(margin:const EdgeInsets.only(bottom:8),elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14),side:const BorderSide(color:Color(0xFFE3E8EF))),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),leading:Container(width:44,height:44,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.folder_outlined,color:Color(0xFF17365D))),title:Text('${x['caseNumber']}',style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF172B4D))),subtitle:Text('${x['area']}  •  ${x['court']??''}',maxLines:1,overflow:TextOverflow.ellipsis),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[_status('${x['status']}'),const SizedBox(height:3),const Icon(Icons.chevron_right,size:17,color:Color(0xFF9AA5B5))]),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CaseDetailsPage(caseData:x))).then((_)=>load())))
  ]);}
  Widget _metricCard(String value,String label,IconData icon)=>Card(elevation:0,child:Padding(padding:const EdgeInsets.symmetric(vertical:14,horizontal:8),child:Column(children:[Icon(icon,size:21,color:const Color(0xFF17365D)),const SizedBox(height:5),Text(value,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:Color(0xFF172B4D))),Text(label,style:const TextStyle(fontSize:10,color:Color(0xFF68778D)))])));
}

class CasesPage extends StatefulWidget { final String? initialArea; const CasesPage({super.key,this.initialArea}); @override State<CasesPage> createState()=>_CasesPageState(); }
class _CasesPageState extends State<CasesPage> {
  List<Map<String,dynamic>> cases=[]; List<Map<String,dynamic>> clients=[];
  final search=TextEditingController();
  String selectedArea='Сите области', selectedStatus='Сите статуси', sortBy='Најнови';
  @override void initState(){super.initState();if(widget.initialArea!=null)selectedArea=widget.initialArea!;load();search.addListener(()=>setState((){}));}
  @override void dispose(){search.dispose();super.dispose();}
  Future<void> load()async{clients=await AppDatabase.instance.db.query('clients',orderBy:'name');cases=await AppDatabase.instance.db.rawQuery('SELECT cases.*, clients.name clientName FROM cases JOIN clients ON clients.id=cases.clientId ORDER BY cases.id DESC');if(mounted)setState((){});}
  Future<void> newCase()async{await Navigator.push(context,MaterialPageRoute(builder:(_)=>NewCasePage(clients:clients)));load();}
  List<Map<String,dynamic>> get filtered {
    final q=search.text.trim().toLowerCase();
    final result=cases.where((x){
      final matchesText=q.isEmpty || '${x['clientName']} ${x['caseNumber']} ${x['area']} ${x['court']??''} ${x['opponent']??''}'.toLowerCase().contains(q);
      final matchesArea=selectedArea=='Сите области' || x['area']==selectedArea;
      final matchesStatus=selectedStatus=='Сите статуси' || x['status']==selectedStatus;
      return matchesText && matchesArea && matchesStatus;
    }).toList();
    if(sortBy=='Број на предмет') result.sort((a,b)=>'${a['caseNumber']}'.compareTo('${b['caseNumber']}'));
    if(sortBy=='Странка') result.sort((a,b)=>'${a['clientName']}'.toLowerCase().compareTo('${b['clientName']}'.toLowerCase()));
    if(sortBy=='Најстари') result.sort((a,b)=>'${a['createdAt']}'.compareTo('${b['createdAt']}'));
    return result;
  }
  Widget _status(String status){final done=status=='Завршен';return Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),decoration:BoxDecoration(color:done?const Color(0xFFE9F7EF):const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(20)),child:Text(status,style:TextStyle(fontSize:12,fontWeight:FontWeight.w800,color:done?const Color(0xFF247A49):const Color(0xFF17365D))));}
  @override Widget build(BuildContext c){
    const areas=caseAreas;
    final shown=filtered;
    final active=cases.where((x)=>x['status']!='Завршен').length; final done=cases.where((x)=>x['status']=='Завршен').length;
    return Scaffold(
      appBar:AppBar(title:const Text('Предмети'),actions:[IconButton(onPressed:load,tooltip:'Освежи',icon:const Icon(Icons.refresh)),IconButton(onPressed:newCase,icon:const Icon(Icons.add))]),
      floatingActionButton:FloatingActionButton.extended(onPressed:newCase,icon:const Icon(Icons.add),label:const Text('Нов предмет')),
      body:Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(12,12,12,8),child:TextField(controller:search,decoration:InputDecoration(hintText:'Пребарај странка, број, област...',prefixIcon:const Icon(Icons.search),suffixIcon:search.text.isEmpty?null:IconButton(onPressed:()=>search.clear(),icon:const Icon(Icons.clear)),filled:true,fillColor:const Color(0xFFF4F6F9),border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))))),
        Padding(padding:const EdgeInsets.fromLTRB(12,0,12,8),child:Row(children:[
          Expanded(child:DropdownButtonFormField<String>(value:selectedArea,decoration:InputDecoration(labelText:'Област',isDense:true,border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))),items:['Сите области',...areas].map((v)=>DropdownMenuItem(value:v,child:Text(v,overflow:TextOverflow.ellipsis))).toList(),onChanged:(v)=>setState(()=>selectedArea=v!))),
          const SizedBox(width:8),
          Expanded(child:DropdownButtonFormField<String>(value:selectedStatus,decoration:InputDecoration(labelText:'Статус',isDense:true,border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))),items:const ['Сите статуси','Активен','Завршен'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setState(()=>selectedStatus=v!))),
        ])),
        Padding(padding:const EdgeInsets.fromLTRB(12,0,12,8),child:Row(children:[
          Text('${shown.length} предмети',style:const TextStyle(fontWeight:FontWeight.w800,color:Color(0xFF172B4D))),const Spacer(),
          Text('Активни $active  •  Завршени $done',style:const TextStyle(fontSize:12,color:Color(0xFF68778D))),const SizedBox(width:8),
          PopupMenuButton<String>(tooltip:'Сортирање',onSelected:(v)=>setState(()=>sortBy=v),itemBuilder:(_)=>const [PopupMenuItem(value:'Најнови',child:Text('Најнови')),PopupMenuItem(value:'Најстари',child:Text('Најстари')),PopupMenuItem(value:'Странка',child:Text('По странка')),PopupMenuItem(value:'Број на предмет',child:Text('По број'))],child:const Icon(Icons.sort)),
        ]),
        Expanded(child:shown.isEmpty?Center(child:Padding(padding:const EdgeInsets.all(30),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(cases.isEmpty?Icons.folder_open_outlined:Icons.search_off_outlined,size:54,color:const Color(0xFF9AA5B5)),const SizedBox(height:12),Text(cases.isEmpty?'Нема внесени предмети.':'Нема предмети според избраните филтри.',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w700,color:Color(0xFF68778D)))]))):ListView.builder(padding:const EdgeInsets.fromLTRB(12,0,12,90),itemCount:shown.length,itemBuilder:(_,i){final x=shown[i];return Card(margin:const EdgeInsets.only(bottom:8),elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14),side:const BorderSide(color:Color(0xFFE3E8EF))),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),leading:Container(width:44,height:44,decoration:BoxDecoration(color:const Color(0xFFEAF0F8),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.folder_outlined,color:Color(0xFF17365D))),title:Text('${x['caseNumber']}',style:const TextStyle(fontWeight:FontWeight.w900,color:Color(0xFF172B4D))),subtitle:Padding(padding:const EdgeInsets.only(top:4),child:Text('${x['clientName']}  •  ${x['area']}',maxLines:1,overflow:TextOverflow.ellipsis)),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[_status('${x['status']}'),const SizedBox(height:4),const Icon(Icons.chevron_right,size:18,color:Color(0xFF9AA5B5))]),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CaseDetailsPage(caseData:x))).then((_)=>load()));}))
      ])
    );
  }
}

class NewCasePage extends StatefulWidget { final List<Map<String,dynamic>> clients; const NewCasePage({super.key,required this.clients}); @override State<NewCasePage> createState()=>_NewCasePageState(); }
class _NewCasePageState extends State<NewCasePage>{ final number=TextEditingController(),court=TextEditingController(),opponent=TextEditingController();
  String area='Граѓанска Постапка';
  static const areas=caseAreas; int? clientId; Future<void> save()async{if(clientId==null||number.text.trim().isEmpty)return; final client=widget.clients.firstWhere((x)=>x['id']==clientId); await AppDatabase.instance.db.insert('cases',{'uid':newUid(),'clientId':clientId,'caseNumber':number.text.trim(),'area':area,'court':court.text.trim(),'opponent':opponent.text.trim(),'status':'Активен','createdAt':nowUtc(),'updatedAt':nowUtc()}); final dir=await createCaseFolders(client:client['name'],caseNumber:number.text); await File(p.join(dir.path,'Тек_на_предметот','почеток.txt')).writeAsString('Предмет креиран: ${DateFormat('dd.MM.yyyy HH:mm').format(DateTime.now())}\nОбласт: ${area}\n'); if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Предметот е креиран.\n${dir.path}')));Navigator.pop(context);}} @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Нов предмет')),body:ListView(padding:const EdgeInsets.all(20),children:[DropdownButtonFormField<int>(value:clientId,decoration:const InputDecoration(labelText:'Странка',border:OutlineInputBorder()),items:widget.clients.map((x)=>DropdownMenuItem(value:x['id'] as int,child:Text(x['name']))).toList(),onChanged:(v)=>setState(()=>clientId=v)),const SizedBox(height:12),TextField(controller:number,decoration:const InputDecoration(labelText:'Број на предмет',border:OutlineInputBorder())),const SizedBox(height:12),DropdownButtonFormField<String>(value:area,decoration:const InputDecoration(labelText:'Област',border:OutlineInputBorder()),items:areas.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setState(()=>area=v!)),const SizedBox(height:12),TextField(controller:court,decoration:const InputDecoration(labelText:'Суд / институција',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:opponent,decoration:const InputDecoration(labelText:'Спротивна страна',border:OutlineInputBorder())),const SizedBox(height:20),FilledButton.icon(onPressed:save,icon:const Icon(Icons.create_new_folder),label:const Text('Креирај предмет и фолдери'))])); }

class CaseDetailsPage extends StatefulWidget {
  final Map<String,dynamic> caseData; const CaseDetailsPage({super.key,required this.caseData});
  @override State<CaseDetailsPage> createState()=>_CaseDetailsPageState();
}
class _CaseDetailsPageState extends State<CaseDetailsPage> {
  List<Map<String,dynamic>> documents=[];
  bool busy=false;
  @override void initState(){super.initState();loadDocuments();}
  List<Map<String,dynamic>> events=[];
  Future<void> loadDocuments() async {
    documents=await AppDatabase.instance.db.query('documents',where:'caseId=?',whereArgs:[widget.caseData['id']],orderBy:'id DESC');
    events=await AppDatabase.instance.db.query('events',where:'caseId=?',whereArgs:[widget.caseData['id']],orderBy:'id DESC');
    if(mounted)setState((){});
  }
  Future<Directory> caseDirectory() async => createCaseFolders(client:widget.caseData['clientName'],caseNumber:widget.caseData['caseNumber'],completed:widget.caseData['status']=='Завршен');
  Future<void> addEvent() async {
    final title=TextEditingController(); final note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Ново дејствие'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Дејствие / настан')),const SizedBox(height:10),TextField(controller:note,maxLines:3,decoration:const InputDecoration(labelText:'Белешка'))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Откажи')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Зачувај'))]));
    if(ok!=true || title.text.trim().isEmpty)return;
    final now=DateTime.now();
    await AppDatabase.instance.db.insert('events',{'uid':newUid(),'caseId':widget.caseData['id'],'eventDate':now.toIso8601String(),'title':title.text.trim(),'note':note.text.trim(),'updatedAt':nowUtc()});
    final dir=await caseDirectory();
    final file=File(p.join(dir.path,'Тек_на_предметот','${DateFormat('yyyyMMdd_HHmmss').format(now)}_${safeName(title.text)}.txt'));
    await file.writeAsString('Датум: ${DateFormat('dd.MM.yyyy HH:mm').format(now)}\n${title.text.trim()}\n${note.text.trim()}');
    await loadDocuments();
  }
  Future<void> completeCase() async {
    if(widget.caseData['status']=='Завршен')return;
    final activeDir=await createCaseFolders(client:widget.caseData['clientName'],caseNumber:widget.caseData['caseNumber']);
    final completedDir=await createCaseFolders(client:widget.caseData['clientName'],caseNumber:widget.caseData['caseNumber'],completed:true);
    if(await completedDir.exists()) {
      // If the destination was pre-created by createCaseFolders, remove it before moving the active folder.
      await completedDir.delete(recursive:true);
    }
    await activeDir.rename(completedDir.path);
    final oldRoot=activeDir.path; final newRoot=completedDir.path;
    final docs=await AppDatabase.instance.db.query('documents',where:'caseId=?',whereArgs:[widget.caseData['id']]);
    for(final d in docs){final oldPath=d['path'].toString(); if(oldPath.startsWith(oldRoot)){await AppDatabase.instance.db.update('documents',{'path':newRoot+oldPath.substring(oldRoot.length)},where:'id=?',whereArgs:[d['id']]);}}
    await AppDatabase.instance.db.update('cases',{'status':'Завршен','updatedAt':nowUtc()},where:'id=?',whereArgs:[widget.caseData['id']]);
    if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Предметот е завршен и преместен во ЗАВРШЕНИ.')));Navigator.pop(context);}
  }
  Future<void> saveDocument(XFile file) async {
    setState(()=>busy=true);
    try {
      final dir=await caseDirectory(); final docsDir=Directory(p.join(dir.path,'Документи')); await docsDir.create(recursive:true);
      final original=File(file.path); final ext=p.extension(file.name).isEmpty ? '.jpg' : p.extension(file.name);
      final stamp=DateFormat('yyyyMMdd_HHmmss').format(DateTime.now()); final base=safeName(p.basenameWithoutExtension(file.name));
      final target=File(p.join(docsDir.path,'${stamp}_${base.isEmpty ? 'скениран_документ' : base}$ext'));
      await original.copy(target.path);
      await AppDatabase.instance.db.insert('documents',{'uid':newUid(),'caseId':widget.caseData['id'],'name':p.basename(target.path),'path':target.path,'createdAt':nowUtc(),'updatedAt':nowUtc()});
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Документот е зачуван во Документи.')));
      await loadDocuments();
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Грешка при зачувување: $e'))); }
    finally { if(mounted)setState(()=>busy=false); }
  }
  Future<void> scan() async {
    if(!Platform.isAndroid && !Platform.isIOS){
      await addFile(); return;
    }
    final image=await ImagePicker().pickImage(source:ImageSource.camera,imageQuality:92);
    if(image!=null) await saveDocument(image);
  }
  Future<void> addFile() async {
    final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['pdf','jpg','jpeg','png','webp'],withData:false);
    if(result==null || result.files.single.path==null)return;
    final path=result.files.single.path!; await saveDocument(XFile(path,name:result.files.single.name));
  }
  Widget _statusChip(BuildContext c, String status) {
    final done = status == 'Завршен';
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: done ? Colors.green.withOpacity(.10) : Theme.of(c).colorScheme.primary.withOpacity(.10), borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(done ? Icons.check_circle : Icons.timelapse, size: 16, color: done ? Colors.green.shade700 : Theme.of(c).colorScheme.primary), const SizedBox(width: 6), Text(status, style: TextStyle(fontWeight: FontWeight.w700, color: done ? Colors.green.shade700 : Theme.of(c).colorScheme.primary))]));
  }

  Widget _info(BuildContext c, IconData icon, String label, String value) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 20, color: Theme.of(c).colorScheme.primary), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: Theme.of(c).textTheme.labelMedium), const SizedBox(height: 2), Text(value.isEmpty ? '—' : value, style: const TextStyle(fontWeight: FontWeight.w600))]))]));

  Widget _sectionTitle(BuildContext c, IconData icon, String title, int count) => Row(children: [Icon(icon, color: Theme.of(c).colorScheme.primary), const SizedBox(width: 9), Expanded(child: Text(title, style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))), Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: Theme.of(c).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(14)), child: Text('$count'))]);

  @override Widget build(BuildContext c) {
    final x=widget.caseData;
    return Scaffold(
      appBar: AppBar(title: Text('Предмет ${x['caseNumber']}'), actions: [IconButton(onPressed: loadDocuments, tooltip: 'Освежи', icon: const Icon(Icons.refresh))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 28), children: [
        Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${x['caseNumber']}', style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text('${x['clientName']}', style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700))])), _statusChip(c, '${x['status']}')]),
          const Divider(height: 28),
          _info(c, Icons.category_outlined, 'Област', '${x['area']}'),
          _info(c, Icons.account_balance_outlined, 'Суд / институција', '${x['court'] ?? ''}'),
          _info(c, Icons.people_outline, 'Спротивна страна', '${x['opponent'] ?? ''}'),
          _info(c, Icons.calendar_today_outlined, 'Креиран', x['createdAt'] == null ? '' : DateFormat('dd.MM.yyyy HH:mm').format(DateTime.parse(x['createdAt'].toString()).toLocal())),
        ])),
        const SizedBox(height: 14),
        Row(children: [Expanded(child: FilledButton.icon(onPressed: busy ? null : scan, icon: const Icon(Icons.document_scanner_outlined), label: Text(Platform.isAndroid ? 'Скенирај документ' : 'Додај документ'))), const SizedBox(width: 10), OutlinedButton(onPressed: busy ? null : addFile, child: const Icon(Icons.attach_file))]),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: OutlinedButton.icon(onPressed: addEvent, icon: const Icon(Icons.add_circle_outline), label: const Text('Ново дејствие'))), if(x['status']=='Активен') ...[const SizedBox(width: 10), Expanded(child: FilledButton.tonalIcon(onPressed: completeCase, icon: const Icon(Icons.check_circle_outline), label: const Text('Заврши')))] ]),
        const SizedBox(height: 24),
        _sectionTitle(c, Icons.timeline, 'Тек на предметот', events.length), const SizedBox(height: 10),
        if(events.isEmpty) Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [Icon(Icons.timeline_outlined, size: 42, color: Theme.of(c).colorScheme.outline), const SizedBox(height: 8), const Text('Сè уште нема внесени дејствија.'), const SizedBox(height: 4), Text('Додајте го првиот настан во постапката.', style: Theme.of(c).textTheme.bodySmall)]))),
        ...events.map((e) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(elevation: 0, child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5), leading: CircleAvatar(child: const Icon(Icons.event, size: 19)), title: Text('${e['title']}', style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text('${DateFormat('dd.MM.yyyy HH:mm').format(DateTime.parse(e['eventDate'].toString()).toLocal())}${(e['note'] ?? '').toString().isEmpty ? '' : '\n${e['note']}'}'))))),
        const SizedBox(height: 18),
        _sectionTitle(c, Icons.folder_copy_outlined, 'Документи', documents.length), const SizedBox(height: 10),
        if(busy) const LinearProgressIndicator(),
        if(documents.isEmpty && !busy) Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [Icon(Icons.description_outlined, size: 42, color: Theme.of(c).colorScheme.outline), const SizedBox(height: 8), const Text('Нема додадени документи.'), const SizedBox(height: 4), Text('Скенирајте или прикачете PDF/слика.', style: Theme.of(c).textTheme.bodySmall)]))),
        ...documents.map((d) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(elevation: 0, child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3), leading: CircleAvatar(child: Icon(d['name'].toString().toLowerCase().endsWith('.pdf') ? Icons.picture_as_pdf : Icons.image_outlined, size: 19)), title: Text(d['name'], maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text(DateFormat('dd.MM.yyyy HH:mm').format(DateTime.parse(d['createdAt'].toString()).toLocal())), trailing: const Icon(Icons.chevron_right), onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(d['path'])))))),
      ]),
    );
  }

}


class SyncPage extends StatefulWidget {
  const SyncPage({super.key});
  @override State<SyncPage> createState()=>_SyncPageState();
}
class _SyncPageState extends State<SyncPage> {
  bool busy=false;
  String status='Подготвено за синхронизација.';
  Map<String,dynamic>? summary;
  String? driveFolder;
  Future<Database> db() async { final path=p.join((await getApplicationDocumentsDirectory()).path,'registar.db'); return openDatabase(path,version:6); }
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    final d=await db(); final s=await SyncService.instance.loadLastSummary(d);
    final meta=await d.query('sync_meta',where:'key=?',whereArgs:['windowsDriveFolder'],limit:1);
    if(mounted)setState((){summary=s;driveFolder=meta.isEmpty?null:meta.first['value']?.toString();});
  }
  Future<void> runSync() async {
    setState((){busy=true;status='Се проверуваат локалните и Drive податоците...';});
    try {
      final result=await SyncService.instance.sync(await db());
      if(mounted){await _load();setState(()=>status='✓ Синхронизацијата е завршена.');}
    } catch(e) { if(mounted)setState(()=>status='Грешка: $e'); }
    finally { if(mounted)setState(()=>busy=false); }
  }
  Widget stat(String value,String label,IconData icon)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(children:[Icon(icon,size:27),const SizedBox(height:5),Text(value,style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)),Text(label,textAlign:TextAlign.center)]))));
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Синхронизација')),
    body:RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const Icon(Icons.cloud_done,size:38),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Google Drive',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const Text('Двонасочна синхронизација')]))]),
        const SizedBox(height:14),Text(status,style:TextStyle(fontWeight:FontWeight.w600,color:status.startsWith('Грешка')?Theme.of(context).colorScheme.error:null)),
        if(busy) ...[const SizedBox(height:12),const LinearProgressIndicator()],
      ]))),
      const SizedBox(height:8),
      Row(children:[stat('${summary?['added']??0}','Додадени',Icons.add_circle_outline),stat('${summary?['updated']??0}','Изменети',Icons.edit_note),stat('${summary?['conflicts']??0}','Конфликти',Icons.warning_amber),stat('${summary?['files']??0}','Документи',Icons.description)]),
      Card(child:ListTile(leading:const Icon(Icons.access_time),title:const Text('Последна синхронизација'),subtitle:Text(summary?['time']?.toString()??'Сè уште нема синхронизација'))),
      if(Platform.isWindows) Card(child:ListTile(leading:const Icon(Icons.folder),title:const Text('Google Drive папка'),subtitle:Text(driveFolder??'Не е избрана'),trailing:TextButton(onPressed:busy?null:()async{final f=await SyncService.instance.chooseWindowsDriveFolder();if(f!=null){final d=await db();await d.insert('sync_meta',{'key':'windowsDriveFolder','value':f},conflictAlgorithm:ConflictAlgorithm.replace);if(mounted)setState(()=>driveFolder=f);}},child:const Text('Промени')))),
      const SizedBox(height:8),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Што се синхронизира',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('• Странки, предмети и тек на предметот\n• PDF и скенирани документи\n• Структурата на папките\n• Промените се спојуваат по уникатен ID\n• При конфликт, поновата верзија има предност')]))),
      const SizedBox(height:16),
      FilledButton.icon(onPressed:busy?null:runSync,icon:const Icon(Icons.sync),label:const Padding(padding:EdgeInsets.symmetric(vertical:12),child:Text('СИНХРОНИЗИРАЈ СЕГА'))),
    ])),
  );
}

class Form extends StatelessWidget { final List<Widget> children; final EdgeInsets padding; const Form({super.key,required this.children,required this.padding}); @override Widget build(BuildContext c)=>SingleChildScrollView(padding:padding,child:Column(children:children)); }
