import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:googleapis/drive/v3.dart' as drive;

const driveScope = 'https://www.googleapis.com/auth/drive.file';

class SyncSummary {
  final int added;
  final int updated;
  final int conflicts;
  final int files;
  final String? error;
  final DateTime time;
  const SyncSummary({required this.added, required this.updated, required this.conflicts, required this.files, required this.time, this.error});
}

class SyncService {
  SyncService._();
  static final instance = SyncService._();
  bool _syncing = false;
  DateTime? _lastRun;
  String? _windowsDriveFolder;
  SyncSummary? lastSummary;

  Future<Directory> localRoot() async {
    final docs = await getApplicationDocumentsDirectory();
    final d = Directory(p.join(docs.path, 'REGISTAR'));
    await d.create(recursive: true);
    return d;
  }

  String _stamp() => DateTime.now().toUtc().toIso8601String();

  Future<Map<String, dynamic>> exportDatabase(Database db) async {
    final root = await localRoot();
    final clients = await db.query('clients');
    final cases = await db.query('cases');
    final events = await db.query('events');
    final rawDocs = await db.query('documents');
    final documents = rawDocs.map((d) {
      final copy = Map<String, dynamic>.from(d);
      final pathValue = (d['path'] ?? '').toString();
      if (pathValue.isNotEmpty) {
        try {
          copy['relativePath'] = p.relative(pathValue, from: root.path);
        } catch (_) {}
      }
      return copy;
    }).toList();

    // Foreign-key references are exported by UID, not by device-local integer IDs.
    final clientUidById = {for (final c in clients) c['id']: c['uid']};
    final caseUidById = {for (final c in cases) c['id']: c['uid']};
    final casesOut = cases.map((row) {
      final x = Map<String, dynamic>.from(row);
      x['clientUid'] = clientUidById[row['clientId']];
      return x;
    }).toList();
    final eventsOut = events.map((row) {
      final x = Map<String, dynamic>.from(row);
      x['caseUid'] = caseUidById[row['caseId']];
      return x;
    }).toList();
    final documentsOut = documents.map((row) {
      final x = Map<String, dynamic>.from(row);
      x['caseUid'] = caseUidById[row['caseId']];
      return x;
    }).toList();

    return {
      'schema': 2,
      'updatedAt': _stamp(),
      'clients': clients,
      'cases': casesOut,
      'events': eventsOut,
      'documents': documentsOut,
    };
  }

  Future<String> exportJson(Database db) async => jsonEncode(await exportDatabase(db));

  Future<String?> chooseWindowsDriveFolder() async {
    if (!Platform.isWindows) return null;
    final result = await FilePicker.platform.getDirectoryPath(dialogTitle: 'Избери Google Drive папка');
    if (result != null) _windowsDriveFolder = result;
    return result;
  }

  Future<void> _copyTree(Directory src, Directory dst) async {
    if (!src.existsSync()) return;
    await dst.create(recursive: true);
    await for (final entity in src.list(recursive: false, followLinks: false)) {
      final target = p.join(dst.path, p.basename(entity.path));
      if (entity is Directory) {
        await _copyTree(entity, Directory(target));
      } else if (entity is File) {
        await File(target).parent.create(recursive: true);
        await entity.copy(target);
      }
    }
  }

  Future<void> _mergeFileTrees(Directory local, Directory remote) async {
    if (!remote.existsSync()) return;
    await remote.create(recursive: true);
    await for (final entity in remote.list(recursive: true, followLinks: false)) {
      if (entity is! File) continue;
      final rel = p.relative(entity.path, from: remote.path);
      final target = File(p.join(local.path, rel));
      await target.parent.create(recursive: true);
      if (!target.existsSync() || (await entity.lastModified()).isAfter(await target.lastModified())) {
        await entity.copy(target.path);
      }
    }
  }

  DateTime _parseDate(dynamic value) => DateTime.tryParse((value ?? '').toString())?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);

  Future<int> _countConflicts(Database db, Map<String, dynamic> remote) async {
    final last = await db.query('sync_meta', where:'key=?', whereArgs:['lastSyncIso'], limit:1);
    final lastSync = last.isEmpty ? DateTime.fromMillisecondsSinceEpoch(0, isUtc:true) : _parseDate(last.first['value']);
    int conflicts = 0;
    Future<void> check(String table) async {
      final locals = await db.query(table);
      final byUid = {for (final x in locals) x['uid'].toString(): x};
      for (final raw in (remote[table] as List? ?? const [])) {
        final x = Map<String,dynamic>.from(raw as Map);
        final uid=(x['uid']??'').toString();
        final local=byUid[uid];
        if (uid.isNotEmpty && local != null && _parseDate(local['updatedAt']).isAfter(lastSync) && _parseDate(x['updatedAt']).isAfter(lastSync)) conflicts++;
      }
    }
    await check('clients'); await check('cases'); await check('events'); await check('documents');
    return conflicts;
  }

  Future<void> _saveSummary(Database db, SyncSummary s) async {
    lastSummary=s;
    await db.insert('sync_meta', {'key':'lastSyncSummary','value':jsonEncode({'added':s.added,'updated':s.updated,'conflicts':s.conflicts,'files':s.files,'time':s.time.toIso8601String(),'error':s.error})}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> _mergeRegistry(Database db, Map<String, dynamic> remote) async {
    final tx = db.transaction((txn) async {
      final localClients = await txn.query('clients');
      final localCases = await txn.query('cases');
      final localEvents = await txn.query('events');
      final localDocs = await txn.query('documents');
      final clientIdByUid = {for (final x in localClients) x['uid'].toString(): x['id']};
      final caseIdByUid = {for (final x in localCases) x['uid'].toString(): x['id']};

      for (final raw in (remote['clients'] as List? ?? const [])) {
        final x = Map<String, dynamic>.from(raw as Map);
        final uid = (x['uid'] ?? '').toString();
        if (uid.isEmpty) continue;
        final old = localClients.where((r) => r['uid'] == uid).firstOrNull;
        if (old == null) {
          x.remove('id');
          await txn.insert('clients', {
            'uid': uid, 'name': x['name'] ?? '', 'phone': x['phone'], 'note': x['note'],
            'updatedAt': x['updatedAt'] ?? _stamp(),
          });
        } else if (_parseDate(x['updatedAt']).isAfter(_parseDate(old['updatedAt']))) {
          await txn.update('clients', {'name':x['name'],'phone':x['phone'],'note':x['note'],'updatedAt':x['updatedAt']}, where:'id=?', whereArgs:[old['id']]);
        }
      }

      final refreshedClients = await txn.query('clients');
      clientIdByUid
        ..clear()
        ..addEntries(refreshedClients.map((x) => MapEntry(x['uid'].toString(), x['id'])));

      for (final raw in (remote['cases'] as List? ?? const [])) {
        final x = Map<String, dynamic>.from(raw as Map);
        final uid = (x['uid'] ?? '').toString();
        final clientUid = (x['clientUid'] ?? '').toString();
        final clientId = clientIdByUid[clientUid];
        if (uid.isEmpty || clientId == null) continue;
        final old = localCases.where((r) => r['uid'] == uid).firstOrNull;
        final values = {
          'uid':uid,'clientId':clientId,'caseNumber':x['caseNumber'],'area':x['area'],'court':x['court'],
          'opponent':x['opponent'],'status':x['status'],'createdAt':x['createdAt'],'updatedAt':x['updatedAt'] ?? _stamp(),
        };
        if (old == null) {
          await txn.insert('cases', values);
        } else if (_parseDate(x['updatedAt']).isAfter(_parseDate(old['updatedAt']))) {
          await txn.update('cases', values..remove('uid'), where:'id=?', whereArgs:[old['id']]);
        }
      }

      final refreshedCases = await txn.query('cases');
      caseIdByUid
        ..clear()
        ..addEntries(refreshedCases.map((x) => MapEntry(x['uid'].toString(), x['id'])));

      for (final raw in (remote['events'] as List? ?? const [])) {
        final x = Map<String, dynamic>.from(raw as Map);
        final uid = (x['uid'] ?? '').toString();
        final caseId = caseIdByUid[(x['caseUid'] ?? '').toString()];
        if (uid.isEmpty || caseId == null) continue;
        final old = localEvents.where((r) => r['uid'] == uid).firstOrNull;
        final values = {'uid':uid,'caseId':caseId,'eventDate':x['eventDate'],'title':x['title'],'note':x['note'],'updatedAt':x['updatedAt'] ?? _stamp()};
        if (old == null) await txn.insert('events', values);
        else if (_parseDate(x['updatedAt']).isAfter(_parseDate(old['updatedAt']))) await txn.update('events', values..remove('uid'), where:'id=?', whereArgs:[old['id']]);
      }

      for (final raw in (remote['documents'] as List? ?? const [])) {
        final x = Map<String, dynamic>.from(raw as Map);
        final uid = (x['uid'] ?? '').toString();
        final caseId = caseIdByUid[(x['caseUid'] ?? '').toString()];
        if (uid.isEmpty || caseId == null) continue;
        final old = localDocs.where((r) => r['uid'] == uid).firstOrNull;
        final values = {'uid':uid,'caseId':caseId,'name':x['name'],'path':x['path'] ?? '', 'createdAt':x['createdAt'],'updatedAt':x['updatedAt'] ?? _stamp()};
        if (old == null) await txn.insert('documents', values);
        else if (_parseDate(x['updatedAt']).isAfter(_parseDate(old['updatedAt']))) await txn.update('documents', values..remove('uid'), where:'id=?', whereArgs:[old['id']]);
      }
    });
    await tx;
  }

  Future<void> _repairDocumentPaths(Database db) async {
    final root = await localRoot();
    final docs = await db.query('documents');
    for (final d in docs) {
      final relative = (d['path'] ?? '').toString();
      final candidate = relative.startsWith(root.path) ? relative : p.join(root.path, p.basename(relative));
      if (File(candidate).existsSync()) {
        await db.update('documents', {'path': candidate}, where:'id=?', whereArgs:[d['id']]);
      }
    }
  }

  // ---------------- Android / Google Drive ----------------
  Future<drive.DriveApi> _androidDrive() async {
    final signIn = GoogleSignIn.instance;
    await signIn.initialize();
    var user = signIn.currentUser;
    user ??= await signIn.authenticate();
    final authorization = await user.authorizationClient.authorizeScopes([driveScope]);
    return drive.DriveApi(authorization.authClient(scopes: [driveScope]));
  }

  Future<String> _ensureFolder(drive.DriveApi api, String name, String? parentId) async {
    final escaped = name.replaceAll("'", "\\'");
    var q = "name = '$escaped' and mimeType = 'application/vnd.google-apps.folder' and trashed = false";
    if (parentId != null) q += " and '$parentId' in parents";
    else q += " and 'root' in parents";
    final list = await api.files.list(q: q, spaces:'drive', $fields:'files(id,name)');
    if ((list.files ?? []).isNotEmpty) return list.files!.first.id!;
    final f = drive.File()..name=name..mimeType='application/vnd.google-apps.folder';
    if (parentId != null) f.parents=[parentId];
    return (await api.files.create(f, $fields:'id')).id!;
  }

  String _mime(String name) {
    switch (p.extension(name).toLowerCase()) {
      case '.pdf': return 'application/pdf';
      case '.png': return 'image/png';
      case '.jpg':
      case '.jpeg': return 'image/jpeg';
      case '.webp': return 'image/webp';
      case '.json': return 'application/json';
      case '.txt': return 'text/plain';
      default: return 'application/octet-stream';
    }
  }

  Future<void> _upload(drive.DriveApi api, File file, String parentId) async {
    final name=p.basename(file.path);
    final escaped=name.replaceAll("'", "\\'");
    final q="name = '$escaped' and '$parentId' in parents and trashed = false";
    final existing=await api.files.list(q:q, spaces:'drive', $fields:'files(id,name)');
    final media=drive.Media(file.openRead(), await file.length(), contentType:_mime(name));
    if ((existing.files ?? []).isEmpty) await api.files.create(drive.File()..name=name..parents=[parentId], uploadMedia:media, $fields:'id');
    else await api.files.update(drive.File()..name=name, existing.files!.first.id!, uploadMedia:media, $fields:'id');
  }

  Future<void> _downloadDriveTree(drive.DriveApi api, String folderId, Directory destination) async {
    await destination.create(recursive:true);
    final list=await api.files.list(q:"'$folderId' in parents and trashed = false", spaces:'drive', $fields:'files(id,name,mimeType)');
    for (final item in (list.files ?? [])) {
      if (item.id == null || item.name == null) continue;
      if (item.mimeType == 'application/vnd.google-apps.folder') {
        await _downloadDriveTree(api, item.id!, Directory(p.join(destination.path,item.name!)));
      } else if (item.mimeType != 'application/vnd.google-apps.shortcut') {
        final media=await api.files.get(item.id!, downloadOptions:drive.DownloadOptions.fullMedia) as drive.Media;
        final out=File(p.join(destination.path,item.name!));
        await out.parent.create(recursive:true);
        final sink=out.openWrite();
        await media.stream.pipe(sink);
        await sink.close();
      }
    }
  }

  Future<String?> _findChildFile(drive.DriveApi api, String parentId, String name) async {
    final e=name.replaceAll("'", "\\'");
    final r=await api.files.list(q:"name = '$e' and '$parentId' in parents and trashed = false", spaces:'drive', $fields:'files(id,name,mimeType)');
    return (r.files ?? []).isEmpty ? null : r.files!.first.id;
  }

  Future<Map<String,dynamic>?> _downloadRemoteRegistry(drive.DriveApi api, String rootId) async {
    final id=await _findChildFile(api, rootId, 'registry.json');
    if (id == null) return null;
    final media=await api.files.get(id, downloadOptions:drive.DownloadOptions.fullMedia) as drive.Media;
    final bytes=await media.stream.toBytes();
    return jsonDecode(utf8.decode(bytes)) as Map<String,dynamic>;
  }

  Future<void> syncToGoogleDrive(Database db) async {
    final api=await _androidDrive();
    final rootId=await _ensureFolder(api,'PREDMETI_REGISTAR',null);
    final remoteDir=Directory(p.join((await getTemporaryDirectory()).path,'predmeti_registar_remote'));
    if (remoteDir.existsSync()) await remoteDir.delete(recursive:true);
    await remoteDir.create(recursive:true);
    final remoteRegistry=await _downloadRemoteRegistry(api,rootId);
    if (remoteRegistry != null) {
      await _mergeRegistry(db,remoteRegistry);
      await _downloadDriveTree(api,rootId,remoteDir);
      await _mergeFileTrees(await localRoot(), remoteDir);
    }
    await _repairDocumentPaths(db);
    final local=await localRoot();
    final registry=File(p.join(local.path,'registry.json'))..createSync(recursive:true);
    await registry.writeAsString(await exportJson(db));
    await _upload(api,registry,rootId);
    await for (final entity in local.list(recursive:true,followLinks:false)) {
      if (entity is! File || p.basename(entity.path)=='registry.json') continue;
      final rel=p.relative(entity.path,from:local.path);
      final parts=p.split(rel); parts.removeLast();
      var parent=rootId;
      for(final part in parts) parent=await _ensureFolder(api,part,parent);
      await _upload(api,entity,parent);
    }
  }

  // ---------------- Windows / Google Drive for Desktop ----------------
  Future<void> syncToWindowsDrive(Database db, {bool automatic = false}) async {
    var folder = _windowsDriveFolder;
    if (folder == null) {
      final rows = await db.query('sync_meta', where:'key=?', whereArgs:['windowsDriveFolder'], limit:1);
      folder = rows.isEmpty ? null : rows.first['value']?.toString();
      _windowsDriveFolder = folder;
    }
    if(folder==null && automatic) return;
    folder ??= await chooseWindowsDriveFolder();
    if(folder==null) throw Exception('Не е избрана Google Drive папка.');
    await db.insert('sync_meta', {'key':'windowsDriveFolder','value':folder}, conflictAlgorithm: ConflictAlgorithm.replace);
    final cloudRoot=Directory(p.join(folder,'REGISTAR'));
    await cloudRoot.create(recursive:true);
    final cloudRegistry=File(p.join(cloudRoot.path,'registry.json'));
    if(cloudRegistry.existsSync()) {
      try {
        final remote=jsonDecode(await cloudRegistry.readAsString()) as Map<String,dynamic>;
        await _mergeRegistry(db,remote);
      } catch (_) {}
    }
    final local=await localRoot();
    final remoteFiles=Directory(p.join(cloudRoot.path,'FILES'));
    if(remoteFiles.existsSync()) await _mergeFileTrees(local,remoteFiles);
    await _repairDocumentPaths(db);
    final registry=File(p.join(local.path,'registry.json'));
    await registry.writeAsString(await exportJson(db));
    await _copyTree(local,remoteFiles);
  }

  Future<SyncSummary?> sync(Database db, {bool automatic = false}) async {
    if (_syncing) return null;
    if (automatic && _lastRun != null && DateTime.now().difference(_lastRun!) < const Duration(seconds: 30)) return null;
    _syncing = true;
    final before = (await db.query('clients')).length + (await db.query('cases')).length + (await db.query('events')).length + (await db.query('documents')).length;
    try {
      if(Platform.isAndroid) await syncToGoogleDrive(db);
      else if(Platform.isWindows) await syncToWindowsDrive(db, automatic: automatic);
      else throw Exception('Оваа верзија е подготвена за Android и Windows.');
      final after = (await db.query('clients')).length + (await db.query('cases')).length + (await db.query('events')).length + (await db.query('documents')).length;
      final now=DateTime.now();
      final summary=SyncSummary(added:(after-before).clamp(0,999999),updated:0,conflicts:0,files:(await db.query('documents')).length,time:now);
      _lastRun = now;
      await db.insert('sync_meta', {'key':'lastSync','value':DateFormat('dd.MM.yyyy HH:mm:ss').format(now)}, conflictAlgorithm: ConflictAlgorithm.replace);
      await db.insert('sync_meta', {'key':'lastSyncIso','value':now.toUtc().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.replace);
      await _saveSummary(db,summary);
      return summary;
    } catch (e) {
      final summary=SyncSummary(added:0,updated:0,conflicts:0,files:0,time:DateTime.now(),error:e.toString());
      await _saveSummary(db,summary);
      rethrow;
    } finally {
      _syncing = false;
    }
  }

  Future<Map<String,dynamic>?> loadLastSummary(Database db) async {
    final rows=await db.query('sync_meta',where:'key=?',whereArgs:['lastSyncSummary'],limit:1);
    if(rows.isEmpty) return null;
    try{return jsonDecode(rows.first['value'].toString()) as Map<String,dynamic>;}catch(_){return null;}
  }
}

class SyncPage extends StatefulWidget {
  const SyncPage({super.key});
  @override State<SyncPage> createState()=>_SyncPageState();
}
class _SyncPageState extends State<SyncPage> {
  bool busy=false;
  String status='Не е синхронизирано.';
  Future<Database> db() async {
    final path=p.join((await getApplicationDocumentsDirectory()).path,'registar.db');
    return openDatabase(path,version:6);
  }
  Future<void> runSync() async {
    setState((){busy=true;status='Се преземаат промените и се спојуваат...';});
    try {
      await SyncService.instance.sync(await db());
      if(mounted)setState(()=>status='✓ Двонасочната синхронизација е завршена.');
    } catch(e) {
      if(mounted)setState(()=>status='Грешка: $e');
    } finally { if(mounted)setState(()=>busy=false); }
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Google Drive — двонасочна синхронизација')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      const Icon(Icons.sync_alt,size:64),const SizedBox(height:16),
      const Text('Двонасочна синхронизација',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:10),
      const Text('Промените од Android и Windows се спојуваат по уникатен ID. Ако истиот запис е променет на двете места, поновата промена има предност. При стартување и повторно отворање на апликацијата се прави автоматски обид за синхронизација.'),
      const SizedBox(height:20),
      if(Platform.isWindows) OutlinedButton.icon(onPressed:busy?null:()async{final f=await SyncService.instance.chooseWindowsDriveFolder();if(mounted&&f!=null)setState(()=>status='Избрана: $f');},icon:const Icon(Icons.folder),label:const Text('Избери Google Drive папка')),
      const SizedBox(height:12),
      FilledButton.icon(onPressed:busy?null:runSync,icon:const Icon(Icons.sync),label:const Text('Синхронизирај во двете насоки')),
      const SizedBox(height:20),if(busy)const LinearProgressIndicator(),const SizedBox(height:12),Text(status),
    ]),
  );
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
